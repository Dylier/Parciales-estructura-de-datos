coorri = 100
anchoVe = 1700
largoVe = 800